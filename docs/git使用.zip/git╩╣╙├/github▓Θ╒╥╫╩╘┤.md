## github下载项目

```
git clone github仓库地址
```

## github搜索资源小技巧

常用前缀后缀

- 找百科大全 awesome xxx
- 找例子 xxx sample
- 找空项目架子 xxx starter、xxx boilerplate
- 找教程 xxx tutorial

## 好用的仓库，学习项目

[Trending:查看热门语言趋势，流行项目](https://github.com/trending)

[HelloGitHub: 分享 GitHub 上有趣、入门级的开源项目](https://github.com/521xueweihan/HelloGithub)

[阮一峰老师的科技爱好者周刊](https://github.com/ruanyf/weekly)



